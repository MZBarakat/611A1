# ENSF 607 - Assignment 3 Report

By: Group 17

## Exercise 1 - Student Registration System

### Task 1: Draw ER diagram

![Exercise 1-1](a3output1.PNG)

### Task 2: Installing the database with JDBC driver

For this exercise, we used and installed **PostgreSQL** which is an open source relational database. The database was installed from:

<cite>https://www.postgresql.org/</cite> 

In addition to the database, we also installed the **PostgreSQL JDBC Driver** which is an open source JDBC driver for Java that communicates using the PostgreSQL native network protocol. This was installed from:

<cite>https://jdbc.postgresql.org/</cite> 

We added the JDBC jar to our project in eclipse by adding the external library through the Java Build Path. A database was then created for ENSF 607 called `ENSF607` using the following SQL through the Admin GUI:

`CREATE DATABASE ENSF607;`

Subsequently, we added the three tables based on the ER diagram using the following SQL code:

**Student Table**:

```C
CREATE TABLE Student(
Id varchar(10) PRIMARY KEY,
FirstName varchar(50),
LastName varchar(50),
Location varchar(100)
);
```

**Course Table**:

```C
CREATE TABLE Course(
Id varchar(10) PRIMARY KEY,
Name varchar(50),
Title varchar(50)
);
```

**Registration Table**:

```C
CREATE TABLE Registration(
id varchar(10),
course_id varchar(10) REFERENCES course(id),
student_id varchar(10) REFERENCES student(id)
);
```

### Task 3: Populating the database

The database was populated using the following SQL, note these are just some examples:

```C
INSERT INTO Student (Id, FirstName, LastName, Location) 
values 
('1000000001', 'Mike', 'Smith', 'Calgary'),
('1000000002', 'Judy', 'Hanks', 'Toronto'),
('1000000003', 'Steve', 'Miller', 'Vancouver');
```

```C
INSERT INTO Course (Id, Name, Title) 
values 
('1', 'ENSF 607', 'Advanced Software Architecture'),
('2', 'ENSF 608', 'Databases'),
('3', 'ENSF 611', 'Machine Learning');
```

```C
INSERT INTO Registration (Id, course_id, student_id) 
values 
('11','1','1000000001'),
('22','2','1000000002'),
('13','3','1000000003');
```

### Task 4: Correct connection string

The connection was established by JDBC using the following code. Note that the user and password can be different depending on the setup of PostGresSQL:

```C
Connection connection;
String db = "ENSF607";
String url = "jdbc:postgresql://localhost/" + db;
String user = "postgres";
String passowrd = "root";
try {
connection = DriverManager.getConnection(url, user, passowrd);
}catch (SQLException e) {
	e.printStackTrace();
	System.exit(0);
}
```

### Task 5: Demonstrating the three queries via java code

The tables can be queried using the following java code, see full code in documentation section:

```C
private void queryTable(String tableName) throws SQLException {
	// Create sql statement to query table
	System.out.println("\n" + tableName.toUpperCase() + " TABLE:");
	Statement sqlStatement = connection.createStatement();

	// Retrieve results and header info
	ResultSet rs = sqlStatement.executeQuery("SELECT * from " + tableName);
	ResultSetMetaData rsmd=rs.getMetaData();
	int columnCount = rsmd.getColumnCount();
	String header = "";
	for (int i = 1; i <= columnCount; i++ ) {
       header += rsmd.getColumnName(i) + ", ";

	}
	
	System.out.println(header);
	
	// Iterate over results
	while(rs.next()) {
	  String tableRow = "";
        for (int i = 1; i <= columnCount; i++) {
        	tableRow += rs.getString(i) + ", ";          
        }
        System.out.println(tableRow);
	}
	
	sqlStatement.close();
}
```


### Task 6: Documentation

#### ER Diagram

Below are the main points and some explanation of why the ER diagram is created in this format:

 - `Student` & `Course` entities: Both are strong entities with id being the key attribute for both.
 - `Registration` entity: A ternary relationship which is represented as a weak entity. In other words, the registration entity would not exist without the student and course entity. E.g you cannot register a student to a course without ensuring you at least have one student and one course
 
#### Screen print of the database and JDBC install

<img src="a3output2.PNG" alt="Exercise 1-21" height="700px"/>


![Exercise 1-22](a3output3.PNG)

#### Commented Source code

```C
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Class Name: Exercise1
 * 
 * Implements/Tests the exercise 1 tasks
 * 
 * @author Group 17
 * @version 1.0
 * @since October 16, 2023
 *
 */
public class Exercise1 {

	/**
	* JDBC connection url
	*/
	private String url = "jdbc:postgresql://localhost/ENSF607";
	
	/**
	* Postgres user
	*/
	private String user = "postgres";
	
	/**
	* Postgres pass
	*/
	private String passowrd = "root";
	
	/**
	* JDBC-Postgres connection
	*/
	private Connection connection;
	
	 /**
   	 * Main method. Tests the Exercise 1 Tasks.
   	 * @param args The command line arguments.
	 * @throws SQLException
   	 **/
	public static void main(String[] args) throws SQLException{
		Exercise1 exercise1 = new Exercise1();
		
		//connect to db
		exercise1.connect();
		
		//query the three tables
		exercise1.queryTable("Student");
		exercise1.queryTable("Course");
		exercise1.queryTable("Registration");
		
		//close the connection
		exercise1.closeConnection();
		
	}
	
	/**
	* Creates a connection to the database
	*/
	private void connect() {
		try {
			// Create connection
			connection = DriverManager.getConnection(url, user, passowrd);
			System.out.println("Connected successfully..."); 
		} catch (SQLException e) {
			// Error
			System.out.println("Unable to connect..."); 
			e.printStackTrace();
		}
	}
	
	/**
	* Closes the connection to the database
	* @throws SQLException
	*/
	private void closeConnection() throws SQLException {
		if(connection!=null) {
			connection.close();
		}
	}
	
	/**
	* Queries a table and shows the results
	* @param tableName the table to be queried
	* @throws SQLException
	*/
	private void queryTable(String tableName) throws SQLException {
		// Create sql statement to query table
		System.out.println("\n" + tableName.toUpperCase() + " TABLE:");
		Statement sqlStatement = connection.createStatement();
	
		// Retrieve results and header info
		ResultSet rs = sqlStatement.executeQuery("SELECT * from " + tableName);
		ResultSetMetaData rsmd = rs.getMetaData();
		int columnCount = rsmd.getColumnCount();
		String header = "";
		for (int i = 1; i <= columnCount; i++ ) {
	       header += rsmd.getColumnName(i) + ", ";
		}
		
		System.out.println(header);
		
		// Iterate over results
		while(rs.next()) {
		  String tableRow = "";
	        for (int i = 1; i <= columnCount; i++) {
	        	tableRow += rs.getString(i) + ", ";          
	        }
	        System.out.println(tableRow);
		}
		
		//close
		sqlStatement.close();
	}
}

```

#### Output of the three queries

![Exercise 1-4](a3output4.PNG)

## Exercise 2 - Building an Incident Management Dashboard



### The SQL scripts for your tables

The following are the SQL scripts to generate the required tables note:
- postgres type for an int primary key which auto increments is serial
- postgres type for datetime is timestamp


**EventActivity Table**:

```C
CREATE TABLE EventActivity(
ID serial primary key,
Activityname varchar(50)
);
```

**EventOrigin Table**:

```C
CREATE TABLE EventOrigin(
ID serial primary key,
Activityname varchar(50)
);
```

**EventStatus Table**:

```C
CREATE TABLE EventStatus(
ID serial primary key,
Status varchar(20)
);
```

**EventClass Table**:

```C
CREATE TABLE EventClass(
ID serial primary key,
Class varchar(20)
);
```

**EventClass Table**:

```C
CREATE TABLE EventLog(
ID serial primary key,
Caseid varchar(20),
Activity varchar(20) REFERENCES EventActivity(Activityname),
Urgency varchar(1),
Impact varchar(1),
Priority varchar(1),
StartDate date,
EndDate date,
TicketStatus varchar(20) REFERENCES EventStatus(Status),
UpdateDateTime timestamp,
Duration integer,
Origin varchar(20) REFERENCES EventOrigin(Activityname),
Class varchar(20) REFERENCES EventClass(Class)
);
```

###  Source code for the generator program

```C
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedWriter;

/**
 * Class Name: Generator
 * 
 * Implements the exercise 2 tasks
 * 
 * @author Group 17
 * @version 1.0
 * @since October 16, 2023
 *
 */
public class Generator {

	/**
	* JDBC connection url
	*/
	private String url = "jdbc:postgresql://localhost/ENSF607";
	
	/**
	* Postgres user
	*/
	private String user = "postgres";
	
	/**
	* Postgres pass
	*/
	private String passowrd = "root";
	
	/**
	* JDBC-Postgres connection
	*/
	private Connection connection;
	
	/**
	* Prefix for case id
	*/
	private static String CID_PREFIX = "CS_";
	
	private static int URGENCY_M[] = {1,2,3};
	private static int IMPACT_M[] = {1,2,3};
	
	PrintWriter pw = null;
	
	public Generator() {
		
	}
	
	/**
	* Creates a connection to the database
	*/
	public void connect() {
		try {
			// Create connection
			connection = DriverManager.getConnection(url, user, passowrd);
			System.out.println("Connected successfully..."); 
		} catch (SQLException e) {
			// Error
			System.out.println("Unable to connect..."); 
			e.printStackTrace();
		}
	}
	
	/**
	* Closes the connection to the database
	* @throws SQLException
	*/
	public void closeConnection() throws SQLException {
		if(connection!=null) {
			connection.close();
		}
	}
	
	/**
	* Queries a table and shows the results
	* @param tableName the table to be queried
	* @throws SQLException
	*/
	public void queryTable(String tableName) throws SQLException {
		// Create sql statement to query table
		System.out.println("\n" + tableName.toUpperCase() + " TABLE:");
		Statement sqlStatement = connection.createStatement();
	
		// Retrieve results and header info
		ResultSet rs = sqlStatement.executeQuery("SELECT * from " + tableName);
		ResultSetMetaData rsmd = rs.getMetaData();
		int columnCount = rsmd.getColumnCount();
		String header = "";
		for (int i = 1; i <= columnCount; i++ ) {
	       header += rsmd.getColumnName(i) + ", ";
		}
		
		System.out.println(header);
		
		// Iterate over results
		while(rs.next()) {
		  String tableRow = "";
	        for (int i = 1; i <= columnCount; i++) {
	        	tableRow += rs.getString(i) + ", ";          
	        }
	        System.out.println(tableRow);
		}
		
		//close
		rs.close();
		sqlStatement.close();
	}
	
	/**
	* Queries a table and gets the count
	* @param tableName the table to be queried
	* @throws SQLException
	*/
	public int getCount(String tableName) throws SQLException {
		// Create sql statement to query table
		Statement sqlStatement = connection.createStatement();
	
		// Retrieve results
		ResultSet rs = sqlStatement.executeQuery("SELECT count(*) AS total from " + tableName);
		rs.next();
		int res = rs.getInt("total");
		//close
		rs.close();
		sqlStatement.close();
		
		return res;
	}
	
	/**
	* Queries a table and gets a random value of that column
	* @param tableName the table to be queried
	* @param columnName the table column
	* @throws SQLException
	*/
	public String getRandomTicketValue(String tableName, String columnName) throws SQLException {
		// Create sql statement to query table
		Statement sqlStatement = connection.createStatement();
	
		// Retrieve results 
		ResultSet rs = sqlStatement.executeQuery("SELECT " + columnName 
				+ " from " + tableName + " ORDER BY random() LIMIT 1");
		
		rs.next();
		String res = rs.getString(columnName);
		//close
		rs.close();
		sqlStatement.close();
		
		return res;
	}
	
	
	/**
	* Exports a log of the query provided
	* @param query the query to execute
	* @param fileName the name/path of the file
	* @throws SQLException
	* @throws IOException 
	*/
	public void exportLog(String query, String fileName) throws SQLException, IOException {
		// Create sql statement to query table
		Statement sqlStatement = connection.createStatement();
	
		// Retrieve results 
		ResultSet rs = sqlStatement.executeQuery(query);
		ResultSetMetaData rsmd = rs.getMetaData();
		
		int columnCount = rsmd.getColumnCount();

		//Loop and write
		int j = 0;
		try (BufferedWriter out = new BufferedWriter(new FileWriter(fileName))) {
			
		    while (rs.next()) {
		    	 for (int i = 1; i <= columnCount; i++) {
		    		  	out.write(rs.getObject(i) + ", ");
				               
			      }
		    	 out.newLine();  
		    	 j++;
		    	 if(j % 1000 == 0)
		    	        out.flush();
		      
		    }
		    System.out.println("Successfully created log"); 
		    out.close();
		}
		
		//close
		rs.close();
		sqlStatement.close();
		
	}
	
	/**
	* Queries a table and adds the values to that column
	* @param tableName the table to be queried
	* @param columnName the table column
	* @param values the values to be inserted into that column
	* @throws SQLException
	*/
	public void addToTableColumn(String tableName, String tableColumn, String[] values) throws SQLException {
		// Create sql statement to query table
		System.out.println("\nINSERTING INTO " + tableName.toUpperCase() + "...");
		

		String sqlInsertStatement = "INSERT INTO " + tableName + " (" + tableColumn + ")" + " VALUES "
		+ " (?);";
		
		//prepare statement
		PreparedStatement ps = connection.prepareStatement(sqlInsertStatement);
		
		//add to batch
		for(String value: values) {
			ps.setString(1, value);
			ps.addBatch();
		}
		
		int[] results = ps.executeBatch();
		
		if(results.length>0) {
			System.out.println("Successfully inserted"); 
		}
		
		//close
		ps.close();
	}
	
	/**
	* Adds sample data to multiple tables
	* @throws SQLException
	*/
	public void addSampleData() throws SQLException {
		
		String[] EventActivities = {"Design","Construction","Test","Password Reset"};
		addToTableColumn("EventActivity", "Activityname", EventActivities);
		
		String[] EventOrigins = {"Joe S.","Bill B.","George E.","Achmed M.","Rona E."};
		addToTableColumn("EventOrigin", "Activityname", EventOrigins);

		String[] EventStatuses = {"Open","On Hold","In Process","Deployed","Deployed Failed"};
		addToTableColumn("EventStatus", "Status", EventStatuses);
		
		String[] EventClasses = {"Change","Incident","Problem","SR"};
		addToTableColumn("EventClass", "Class", EventClasses);
	}
	
	/**
	* Generates a random ticket
	* @param ticketCount the number of tickets to generate
	* @param startDate a string in yyyy-mm-dd format representing the start date
	* @param endDate a string in yyyy-mm-dd format representing the endDate date
	* @throws SQLException
	*/
	public void generateRandomTicket(int ticketCount, String startDate, String endDate) throws SQLException {
		//System.out.println("\nGenerating Random Ticket(s) ...");
		
		Random rand = new Random();
		int count = getCount("EventLog") + 1;
	
		//Insert into the eventlog
		String sqlInsertStatement = "INSERT INTO EventLog " + 
		"(Caseid, Activity, Urgency, Impact, Priority, StartDate, EndDate, TicketStatus, UpdateDateTime, "
				+ "Duration, Origin, Class) VALUES "
				+ " (?,?,?,?,?,?,?,?,?,?,?,?);";
		
		PreparedStatement ps = connection.prepareStatement(sqlInsertStatement);
		
		//add a random ticket
		for(int i=0; i<ticketCount; i++) {
			
			int urgency = URGENCY_M[rand.nextInt(URGENCY_M.length)];
			int impact = IMPACT_M[rand.nextInt(IMPACT_M.length)];
			int priority = calculatePriority(urgency, impact);
			
			int withinDays = rand.nextInt(priority+1);
			
			
			LocalDate sd = generateRandomDate(startDate, endDate);
			LocalDate ed = sd.plusDays(withinDays);
		
			if(withinDays==0) {
				withinDays=1;
			}
			LocalDateTime updateDate = generateRandomDateTime(sd, withinDays);
			
			int duration = calculateDuration(sd, ed);
			
			ps.setString(1, CID_PREFIX + count++);
			ps.setString(2, getRandomTicketValue("EventActivity","Activityname"));
			ps.setString(3, String.valueOf(urgency));
			ps.setString(4, String.valueOf(impact));
			ps.setString(5, String.valueOf(priority));
			ps.setObject(6, sd);
			ps.setObject(7, ed);
			ps.setString(8, getRandomTicketValue("EventStatus","Status"));
			ps.setObject(9, updateDate);
			ps.setInt(10, duration);
			ps.setString(11, getRandomTicketValue("EventOrigin","Activityname"));
			ps.setString(12, getRandomTicketValue("EventClass","Class"));
			ps.addBatch();
		}
		
		int[] results = ps.executeBatch();
		
		if(results.length>0) {
			System.out.println("Successfully generated tickets, count is: " + (count-1)); 
		}
		
		//close
		ps.close();
		
	}
	
	/**
	* Generates a random Date
	* @param startDate a string in yyyy-mm-dd format representing the start date
	* @param endDate a string in yyyy-mm-dd format representing the endDate date
	* @return the random date between the defined ranges
	*/
	private LocalDate generateRandomDate(String dateStart, String dateEnd) {

		LocalDate periodStart = LocalDate.parse(dateStart);
		LocalDate periodEnd = LocalDate.parse(dateEnd);

		int randomDays = new Random().nextInt((int) periodStart.until(periodEnd, ChronoUnit.DAYS));
		
		LocalDate randomizedDate = periodEnd.minusDays(randomDays);
		
		return randomizedDate;
	}
	
	/**
	* Generates a random DateTime
	* @param startDate a date representing the start date
	* @param withinDays the upper limit of the random
	* @return the random datetime between the defined ranges
	*/
	private LocalDateTime generateRandomDateTime(LocalDate startDate, int withinDays) {

		LocalDateTime ldt = startDate.atTime(LocalTime.of(0, 0));
		int randomUpdateDate = new Random().nextInt((int) ldt.until(ldt.plusDays(withinDays), ChronoUnit.HOURS));
		LocalDateTime randomizedDateTime = ldt.plusHours(randomUpdateDate);
		return randomizedDateTime;
	}
	
	/**
	* Calculates the duration between two dates
	* @param startDate a date representing the start date
	* @param endDate a date representing the end date
	* @return the calculated duration
	*/
	private int calculateDuration(LocalDate startDate, LocalDate endDate) {
		return endDate.getDayOfYear() - startDate.getDayOfYear();
	}
	
	/**
	* Calculates the priority based on exercise 2 requirements
	* @param urgency a value representing urgency of the task
	* @param impact a value representing impact of the task
	* @return the calculated priority
	*/
	private int calculatePriority(int urgency, int impact) {
		return urgency + impact - 1;
	}
	
}

```

This can be tested in the following format:

```C
import java.io.IOException;
import java.sql.SQLException;
/**
 * Class Name: Exercise2
 * 
 * Tests the exercise 2 tasks
 * 
 * @author Group 17
 * @version 1.0
 * @since October 16, 2023
 *
 */
public class Exercise2 {

	 /**
   	 * Main method. Tests the Exercise 2 Tasks.
   	 * @param args The command line arguments.
	 * @throws SQLException
   	 **/
	public static void main(String[] args) throws SQLException{
		Generator generator = new Generator();
		
		//connection
		generator.connect();
		
		//generate sample event data
		generator.addSampleData();
		
		//generate random tickets
		generator.generateRandomTicket(10000, "2023-01-30", "2023-06-30");
		
		//generate output file
		try {
			generator.exportLog("Select * from EventLog", "eventlog.txt");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//close
		generator.closeConnection();
				
	}
	

}
```

### Dashboards visualization in a PowerPoint with explanation

The following are the generated dashboard for visualization:
